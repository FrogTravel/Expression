package base;

/**
 * Created by ekaterina on 10/11/17.
 */
public class Primary extends Expression {

}
